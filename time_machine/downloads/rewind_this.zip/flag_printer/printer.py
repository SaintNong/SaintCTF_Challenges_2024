FLAG = "REDACTED" # Nice try!

class FlagPrinter:
    """A class which prints the flag"""

    def __init__(self, print_flag_on_startup=False, flag_override=None):
        if flag_override is not None:
            flag = flag_override
        else:
            flag = FLAG # TODO: use environment variable

        self.flag = flag

        
        # If the flag is set, we print the flag when the class initializes
        if print_flag_on_startup:
            print(FLAG)
    
    # Prints the flag
    def print_flag(self):
        print(self.flag)

# Main function
def main():
    # Create flag printer
    my_flag_printer = FlagPrinter()

    # Print flag
    my_flag_printer.print_flag()


# We use good programming principles here!
if __name__ == "__main__":
    main()
